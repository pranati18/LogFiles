/**Author: Pranati Shrivastava
 * 
 * Project:The goal is to write a parser in Java that parses web server access log file,
 *  loads the log to MySQL and checks if a given IP makes more than a certain number of 
 *  requests for the given duration. This project is performed for the first round of interview for WalletHUb.
 * 
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.*;
public class Parser {

	public static void main(String[] args) throws FileNotFoundException, ParseException {
		
		//Defining the date format
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");


		String startdateArgs=null;
		String threshholdArgs= null;
		String durationArgs= null;
		String FileArgs= null;


		//Default file name
		File filename = new File("access.log");


		//command line parsing arguments logic
		if(args.length>0)
		{        

			for(int i = 0; i < args.length; i++)
			{       

				if((args[i]).contains("--accesslog=")){
					FileArgs = args[i];
				}
				else if((args[i]).contains("--startDate=")){
					startdateArgs = args[i];
				}
				else if((args[i]).contains("--duration=")){
					durationArgs = args[i];
				}
				else if((args[i]).contains("--threshold=")){
					threshholdArgs = args[i];
				}
			}
		}

		//Cleaning the arguments entered
		if(!FileArgs.isEmpty()){
		filename=new File(FileArgs.replace("--accesslog=", ""));
		}

		startdateArgs= startdateArgs.replace("--startDate=","");
		startdateArgs=startdateArgs.replace(".", " ");
		//startdateArgs=startdateArgs.substring(0, startdateArgs.length() - 4);
		startdateArgs=startdateArgs.concat(".000");

		Date startDate= formatter.parse(startdateArgs);
		Date endDate= null;

		String duration = durationArgs.replace("--duration=", "");
		int threshold = Integer.parseInt(threshholdArgs.replace("--threshold=", ""));


		//Adding hour and day to the startdate based on the duration values
		Calendar c = Calendar.getInstance();
		c.setTime(startDate); 
		if (duration.equals("hourly")){
			c.add(Calendar.DATE, 1); // Adding 1 day
			endDate = c.getTime();

		}
		else if(duration.equals("daily")){
			c.add(Calendar.HOUR_OF_DAY,1); // this will add one hour
			endDate = c.getTime();
		}

		//Defining teh object for DAO class.
		ParserDao pd= new ParserDao();

		
		
		/*code to read in the file and store in in an array*/
		int count=0;
		Scanner sc = new Scanner(filename);
		String line;
		String[] value_split = null;
		while(sc.hasNext())
		{

			line=sc.nextLine();
			value_split = line.split("\\|");

			//Calling the function to insert each value of the log file
			pd.InsertLogs(formatter.parse(value_split[0]), value_split[1], value_split[2], Integer.parseInt(value_split[3]), value_split[4]);

			/*if (formatter.parse(value_split[0]).compareTo(startDate) >= 0 && formatter.parse(value_split[0]).compareTo(endDate) <= 0  ){
				 //Date1 is after Date2
				 count++;
			if(count>threshold){
					// System.out.println(value_split[1]);
			 }
			 }*/


		}

		//Calling the function to query the log file to get the correct IP based on the inputs given
		System.out.println(pd.GetIP(startDate, duration, threshold, endDate));

		//Closing File read connection
		sc.close();
	}

}

