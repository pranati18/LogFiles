package com.ef;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

public class ParserDao {
	public boolean InsertLogs(Date date, String IP, String Request, int Status, String User_Agent){
		// TODO Auto-generated method stub

		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String usertype=null;
		boolean status=false;
		int count=0;

		try {
			//Defining the Connection.//THE CONNECTION AUTHENTICATIONS NEEDS TO B ALTERED HERE
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/WalletHub", "root", "root123");

			Timestamp timestamp = new Timestamp(date.getTime());
			//Query to insert all items of the log file.
			pst=con.prepareStatement("insert into Logs values(?,?,?,?,?)");
			pst.setTimestamp(1,timestamp);
			pst.setString(2, IP);
			pst.setString(3, Request);
			pst.setInt(4, Status);
			pst.setString(5, User_Agent);


			count=pst.executeUpdate();


			/*if(count>0){
				System.out.println("applied successfully....");

			}
			else
			{
				System.out.println("Error While Performing DB operation");
			}*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;

	}

	public String GetIP(Date startDate, String duration, int threshold, Date endDate)  
	{

		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String role=null;
		Timestamp start_timestamp = new Timestamp(startDate.getTime());
		Timestamp end_timestamp = new Timestamp(endDate.getTime());

		try {
			//THE CONNECTION AUTHENTICATIONS NEEDS TO B ALTERED HERE
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/WalletHub", "root", "root123");
			//Query to get the correct IP based on the filtering inputs
			pst=con.prepareStatement("SELECT IP FROM log WHERE date BETWEEN ? AND ? GROUP BY IP HAVING count(IP) >= ?;");
			pst.setTimestamp(1, start_timestamp);
			pst.setTimestamp(2,end_timestamp);
			pst.setInt(3, threshold);
			rs=pst.executeQuery();
			if(rs.next())
			{
				role=rs.getString("IP");
				//System.out.println("The IP is fetched from the table: "+role);
			}
			else
			{
				//System.out.println("The Select query failed.");
				return role;
			}
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{

			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return role;
	}



}
